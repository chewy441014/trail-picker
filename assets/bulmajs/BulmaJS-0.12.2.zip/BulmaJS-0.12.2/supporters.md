# BulmaJS Supporters
**This file serves as a directory for the kind, generous BulmaJS users who have supported the BulmaJS project.**

# Patron
The supporters below are those who are currently or have been a regular supporter of this project on [Patreon](https://www.patreon.com/vizuaalog).

### Legendary supporters
There are currently no supporters of this tier.

### Very generous supporters
There are currently no supporters of this tier.

### Generous supporters
There are currently no supporters of this tier.

### Awesome supporters
There are currently no supporters of this tier.

# Paypal
**The supports below are those who have generously donated via Paypal.**

Andreas Pantle